% Description: use an existing k-NN model to classify some testing examples 
%
% Inputs:
% m: a struct containing details of the k-NN model we want to use
% for classification 
% test_examples: a numeric array containing the testing examples we want to
% classify
% 
% Outputs:
% predictions: a categorical array containing the predicted
% labels (i.e., with the same ordering as test_examples)
%
% Notes:
% Assumes that the model m has been created with a call to knn_fit()
% 


function predictions = knn_predict(m, test_examples)

    % Guidance (first task):
    % 1. initialise an empty categorical array to hold the predictions
    % 2. loop over every example in the testing_examples array
    % and... 
    %   a. find its nearest neighbour in the data inside the
    %   model
    %   b. take the label associated with that nearest neighbour as
    %   your prediction
    %   c. add the new prediction onto the end of your categorical
    %   array (from step 1)
    
    % Guidance (second task):
    % adjust your code to take account of the k value set inside the model
    % m. Adjust step a from above so that all k nearest neighbours are
    % found. Adjust step b from above to take the the most common class
    % label across all k nearest neighbours as your prediction

    predictions = categorical;

    % add your code and comments on the lines below:
    distance = [];
    temp = categorical;

    % Calculating the euclidean distance between each row in the test data
    % and the training data
    for i = 1:size(test_examples,1)
        for j = 1:size(m.data,1)
            distance(end+1,:) = knn_calculate_distance(test_examples(i,:),m.data(j,:));
            
            
        end
        % Finding the k(3) nearest neighbours between the data and then
        % storing the most common one as our prediction.
        [val, idx] = mink(distance,m.k);
        temp = m.labels(idx);
        predictions(end+1,:) = mode(temp);
      
        distance = [];
    end
    

end