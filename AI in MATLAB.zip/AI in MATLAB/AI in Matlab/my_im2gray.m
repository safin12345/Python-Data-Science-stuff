% Description: reproduce the im2gray() function behaviour for
% yourself (including some simple Inputs/Outputs comments, below)
%
% Inputs:
% im: an image
% 
% Outputs: 
% im_g: a greyscale image consisting of uint8 values
% 
% Notes: the function should return uint8 values (matching what is passed
% in) but you'll get rounding errors if you perform the conversion
% calculation with uint8 values, so some recasting is needed here
%
function im_g = my_im2gray(im)

    im_g = [];
    % write your code on the lines below:
    % Acquiring the RGB values of the images. The third dimenson contains
    % these RGB values
    R = im(1:end,1:end,1);
    G = im(1:end,1:end,2);
    B = im(1:end,1:end,3);
    
    % Using a 'weighted sum' which attempts to make the image look
    % grayscale to the human eye. Recasting it to a double precision value
    % so we can maintain better accuracy - however it still will not be as
    % accurate as the im2gray function unfortunately.

    im_g = im2double(0.2989 * R + 0.5870 * G + 0.1140 * B);
end